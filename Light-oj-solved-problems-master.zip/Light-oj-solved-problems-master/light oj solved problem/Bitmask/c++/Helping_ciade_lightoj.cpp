    #include <bits/stdc++.h>
    #define ll long long
    using namespace std;
    ///power set resembles binary representation of number;
    ///let (a,b) is a set.then it can be represented through binary representation
    ///0 to 3(means 0 to pow(2,2(sizeofset))-1;
    ///such as 0->000 resembles empty set;
    ///1->001 =a,2->010=b,3->011=ab
    //Link:http://www.geeksforgeeks.org/power-set/
    ll gcd(ll a,ll b){
    if(b==0) return a;
    else gcd(b,a%b);
    }
    ll ara[100];
    ll solve(ll a,ll b)
    {
        int target=(1<<b)-1;
        ll total=0;
        for(int mask=1; mask<=target; mask++)
        {
            int ele=__builtin_popcount(mask)&1;//whether there is only one element in the set or not.
            if(ele==1) ele=1; //when only 1 the we have to add;
            else ele=-1;//else we have to substruct.
            ll den=1;
            for(int  i=0; i<b; i++)
            {
                if(mask&(1<<i))
                {
                    ll g=gcd(ara[i],den);
                    den=(den*ara[i])/g;
                }
            }
             total+=ele*(a/den);
        }
        return total;
    }

    int main()
    {
        ios_base::sync_with_stdio(false);
        cin.tie(NULL);
        int tc;
        cin>>tc;
        for(int i=1; i<=tc; i++)
        {
            ll a,b;
            cin>>a>>b;
            for(int j=0; j<b; j++) cin>>ara[j];
           ll m=solve(a,b);
          printf("Case %d: %d\n",i,a-m);
        }


    }

