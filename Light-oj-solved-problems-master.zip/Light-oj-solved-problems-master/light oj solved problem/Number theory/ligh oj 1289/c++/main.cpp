    //for storing large data in the whole programme we will not use vector it consumes lot memory
    //which will give time limit.
    #include <bits/stdc++.h>
    #define ll unsigned int  //unsigned long long will give memory limit
    #define mod 4294967296
    #define IsComp(n) (_c[n>>6]&(1<<((n>>1)&31))) //to check a bit whethere 0 or not.
    #define SetComp(n) _c[n>>6]|=(1<<((n>>1)&31))
    using namespace std;
    const int MAX =100000000; // 10^8
    const int LMT = 10000; // sqrt(MAX)

    // array of data; each bit tells if a certain number is composite or not
    int  _c[(MAX>>6)+1];
    //int dp[total];

    // we use a STL vector to store the primes
    ll total=0;
    ll tc,no=1;

    // possibly the most important piece for a bitwise sieve
    // these are the macros that check and set a bit
    int primes[5761455];

    int prime_sieve()
    {
        for (ll i = 3; i <= LMT; i += 2)
            if (!IsComp(i))
                for (int j = i*i; j <= MAX; j += i+i)
                    SetComp(j);

        primes[0]=2;
        total++;
   ll     j=1;


        for (ll i=3; i <= MAX; i += 2)
            if (!IsComp(i))
            {
                primes[j++]=i;
                total++;
            }
    }

    ll dp[5761455];
    void calc()
    { ll i;        //in dp we calculated the multiplication of all primes;
                    // in find sqrt we find how many extra primes needs to be multiplied;
        dp[0]=2;
        for(i=1;i<5761456;i++){
            dp[i]=((dp[i-1]%mod)*(primes[i]%mod))%mod;
        }





    }
    int find_sqrt(int n)  // in find sqrt we find how many extra primes needs to be multiplied;
    {
       ll k=sqrt(n);
        ll ret=1,cnt=1,i,now;
      for(i=0;primes[i]<=k;i++){    //here we calculated maximum many powers of prime;
              now=n/primes[i];            //for a particular number ,if we check the primes between squrtof that number
                                                        //that will serve the purpose.
              cnt=1;
              while(now>=primes[i]){
                now/=primes[i];
                cnt=((cnt%mod)*(primes[i]%mod))%mod;
              }
              ret=((ret%mod)*(cnt%mod))%mod;


      }
      return ret;



    }
    int main()
    {
        prime_sieve();
        calc();
        ll a,b,ans,no=1;
        //scanf("%lld",&tc);
        cin>>tc;
        while(tc--)
        {

            //scanf("%lld",&a);
            cin>>a;
            //cout<<dp[total];
           // cout<<primes[total];
            //cout<<dp[10000];
            ans=find_sqrt(a);
           ans=((ans%mod)*(dp[upper_bound(primes,primes+total,a)-primes-1]%mod))%mod;
           cout<<"Case "<<no++<<": "<< ans<<endl;



        }
        return 0;
    }

