#include <bits/stdc++.h>
#define ll  unsigned long long  int
#define mod 1000000007
#define IsComp(n) (_c[n>>6]&(1<<((n>>1)&31))) //to check a bit whethere 0 or not.
#define SetComp(n) _c[n>>6]|=(1<<((n>>1)&31))
using namespace std;
const int MAX = 65540; // as the highest value can be 2^31 thats why i calculated primes upto  sqrt(2^31)
const int LMT = 65540; // sqrt(MAX)

// array of data; each bit tells if a certain number is composite or not
int  _c[(MAX>>6)+1];
//int dp[total];
ll no=1,ans=1,a,b;
//long long int;
// we use a STL vector to store the primes


// possibly the most important piece for a bitwise sieve
// these are the macros that check and set a bit
int primes[65540];

int prime_sieve()
{
    for (ll i = 3; i < LMT; i += 2)
        if (!IsComp(i))  //0 means the number is prime,otherwise not.
            for (ll j = i*i; j < MAX; j += i+i)
                SetComp(j);

    primes[0]=2;
   ll    j=1;


    for (ll i=3; i < MAX; i += 2)
        if (!IsComp(i))
        {
            primes[j++]=i;

        }
}

ll Extended_Euclid(ll A, ll B, ll *X, ll *Y)
{
   ll x, y, u, v, m, n, a, b, q, r;


    x = 0; y = 1;


    u = 1; v = 0;

    for (a = A, b = B; 0 != a; b = a, a = r, x = u, y = v, u = m, v = n)
    {

        q = b / a;
        r = b % a;


        m = x - (u * q);
        n = y - (v * q);
    }


    *X = x; *Y = y;

    return b;
}
ll Pow(ll a,ll b)  // big mod  //larger power with mod;
{
    ll ans=1;
    while(b)
    {
        if(b&1)
        {
            b--;
            ans=((ans%mod)*a)%mod;
        }
        else
        {
            b/=2;
            a=((a%mod)*a)%mod;
        }
    }
    return ans;
}
ll check(ll a,ll cnt)
{

    ll t=1,p,x,y;
  ll d;


           p=Extended_Euclid(a-1,mod,&x,&y);//as the formula have  division that why  i calculate exgcd;
           p=*(&x);
            p=(p+mod)%mod;//for handling negative value;
             t=((t%mod));
             d=(Pow(a,((cnt)+1))-1);//as i calculated pow with mod then it can be negative.

            d=(d+mod)%mod;//that's why for handling negative value i have done this.
             d=(d*p)%mod;
             t=(t*d)%mod;
             return t;
        }



   // cout<<t<<endl;







int main()
{  //freopen("in.txt","r",stdin);
    prime_sieve();
    ll tc;

    cin>>tc;
    while(tc--)
    {
   ans=1;
    cin>>a>>b;
		vector < pair < ll, ll> > fact;

		for (ll i = 0; primes[i] * primes[i] <= a; i++) {   //here we just calculate the prime and their power
                                                                                               //and made the power.
			ll k = 0;
			while(a % primes[i] == 0) {
				k++;
				a = a / primes[i];
			}

			if(k != 0) {
				fact.push_back(make_pair(primes[i], k*b));
			}
		}


		if(a != 1) {
			fact.push_back(make_pair(a, 1*b));
		}
ll t=1;
for (int i = 0; i < fact.size(); i++) {
		ll	p = fact[i].first;
			ll e = fact[i].second;
			t=check(p,e);
			t=t%mod;
			ans=(ans%mod);
			ans=(t*ans)%mod;


		}

       // check();
cout<<"Case "<<no++<<": "<<ans<<endl;


    }


}
/*
->for solving this i have needed first theory how to calculate the SOD for larger power.
***links->1.http://mathschallenge.net/library/number/sum_of_divisors
*/
