#include <bits/stdc++.h>
#include <math.h>
#define ll long long int
#define Max 1000
using namespace std;
ll y;
ll recursion(ll sum,ll a,ll k)
{  ll p,q;

    p=(k*(k+1))/2-(((a-1)*a)/2);
    q=a*(k-a);
   if(q>=0) sum=sum+(p+q);
    if(q<=0) return sum;
   else {
       a++;
   k=y/a;
   if(a>k) return sum;
        recursion(sum,a,k);
   }



}
int main(){
ll tc,cnt=1;
cin>>tc;
while(tc--){
    ll a,x,sum=0;
   scanf("%lld",&y);
    x=recursion(0,2,y/2);
   printf("Case %lld: %lld\n",cnt++,x);


}
}

